package com.example.databasedemo;
import android.provider.BaseColumns;

public interface Constants extends BaseColumns{
    public static final String TABLE_NAME = "events";
    public static final String TIME = "time";
    public  static final String TITLE = "title";

}