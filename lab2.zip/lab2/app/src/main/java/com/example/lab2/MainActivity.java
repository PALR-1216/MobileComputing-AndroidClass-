package com.example.lab2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //a Simple App to manage UI Views and Buttons simple gestures

        //--ALL the UI Buttons--
        Button continueBtn = (Button) findViewById(R.id.continueBtn) ;
        Button aboutBtn = (Button) findViewById(R.id.aboutBtn);
        Button newGameBtn = (Button) findViewById(R.id.newGameBtn);
        Button exitBtn = (Button) findViewById(R.id.exitBtn);


        continueBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onContinue(view);
            }
        });

        aboutBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onAbout(view);
            }
        });

        newGameBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onNewGame(view);
            }
        });


        exitBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onExit(view);
            }
        });






    }

    public void onAbout(View view) {
        Intent intent = new Intent(this, About.class);
        startActivity(intent);
    }

    public void onContinue(View view) {
        Intent intent = new Intent(this, Continue.class);
        startActivity(intent);
    }

    public void onNewGame(View view) {
        Intent intent = new Intent(this, NewGame.class);
        startActivity(intent);
    }

    public void onExit(View view) {
        Intent intent = new Intent(this, Exit.class);
        startActivity(intent);
    }
}